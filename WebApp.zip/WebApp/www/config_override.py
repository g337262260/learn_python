#!user/bin/env python3
# -*- coding:utf-8 -*-

"""覆盖某些默认设置"""

__author__ = 'Guowei'

configs = {
    'db': {
        'host': '192.168.0.100'
    }
}