# Note8

####做项目中的一些不懂的一些东西，做一些笔记

###HTML
###UIKIT:

    https://blog.csdn.net/tr1912/article/details/53700788

####TAG:

    http://www.w3school.com.cn/tags
    
- class :规定元素的类名,用于指向样式表中的类（class）。不过，也可以利用它通过 JavaScript 来改变带有指定 class 的 HTML 元素。


    

    
    

   


     







